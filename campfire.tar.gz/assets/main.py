import pygame
import sys
import asyncio

pygame.init()

# Window
WIDTH = 900
HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Heira's Escape")

# Colors
BLUE = (0, 105, 148)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 0, 0)
GREEN = (0, 200, 0)
PURPLE = (150, 0, 150)
YELLOW = (255, 255, 0)

# Fonts
font = pygame.font.SysFont("arial", 28)
big_font = pygame.font.SysFont("arial", 60)

clock = pygame.time.Clock()

# Game states
scene = 0
dialogue_index = 0
escaped_algae = False

# Character positions
heira = pygame.Rect(100, 300, 150, 150)
siren = pygame.Rect(50, 300, 150, 150)
poseidon = pygame.Rect(650, 300, 60, 60)

# Obstacle algae
algae = pygame.Rect(400, 250, 60, 200)

speed = 7

# Dialogue lines
dialogues = [
    "💬 Poseidon: Now a little fish wins against me?",
    "💬 Poseidon: I am going to kill you!",
    "💬 Poseidon: My siren, go fetch her!!"
]

# Load images
heira_img = pygame.image.load("mermaid swim.jpeg").convert_alpha()
siren_img = pygame.image.load("siren.jpeg").convert_alpha()

heira_img = pygame.transform.scale(heira_img, (150, 150))
siren_img = pygame.transform.scale(siren_img, (150, 150))


def draw_intro():
    screen.fill(BLUE)
    pygame.draw.rect(screen, PURPLE, poseidon)
    screen.blit(font.render("Poseidon", True, WHITE), (poseidon.x-10, poseidon.y-30))
    screen.blit(heira_img, (heira.x, heira.y))
    screen.blit(font.render("Heira the Mermaid", True, WHITE), (heira.x, heira.y-30))

    pygame.draw.circle(screen, WHITE, (350, 300), 10)
    pygame.draw.circle(screen, RED, (380, 300), 10)
    pygame.draw.circle(screen, YELLOW, (410, 300), 10)

    screen.blit(font.render("Heira wins all tokens! Press SPACE", True, WHITE), (200, 100))


def draw_dialogue():
    screen.fill(BLUE)
    pygame.draw.rect(screen, PURPLE, poseidon)
    screen.blit(heira_img, (heira.x, heira.y))

    bubble = pygame.Rect(50, 50, 600, 100)
    pygame.draw.rect(screen, WHITE, bubble, border_radius=10)
    pygame.draw.rect(screen, BLACK, bubble, 3, border_radius=10)

    text = font.render(dialogues[dialogue_index], True, BLACK)
    screen.blit(text, (60, 85))

    screen.blit(font.render("Press SPACE", True, WHITE), (380, 250))


def draw_game():
    screen.fill(BLUE)
    pygame.draw.rect(screen, (0, 150, 0), algae)

    if siren.x < heira.x - 50:
        siren.x += 1
    if siren.y < heira.y:
        siren.y += 1
    elif siren.y > heira.y:
        siren.y -= 1

    screen.blit(siren_img, (siren.x, siren.y))
    screen.blit(heira_img, (heira.x, heira.y))

    screen.blit(font.render("Heira the Mermaid", True, WHITE), (heira.x, heira.y-30))
    screen.blit(font.render("Siren", True, WHITE), (siren.x, siren.y-30))
    screen.blit(font.render("Algae", True, WHITE), (algae.x, algae.y-30))

    screen.blit(font.render("Press UP to avoid algae, then DOWN to continue!", True, WHITE), (180, 50))


def draw_game_over():
    screen.fill(BLUE)
    screen.blit(big_font.render("GAME OVER", True, RED), (300, 250))


def draw_victory():
    screen.fill(BLUE)
    screen.blit(big_font.render("YOU ESCAPED!", True, YELLOW), (280, 250))


async def main():
    global scene, dialogue_index, escaped_algae

    running = True

    while running:
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if scene == 0 and event.key == pygame.K_SPACE:
                    scene = 1
                elif scene == 1 and event.key == pygame.K_SPACE:
                    dialogue_index += 1
                    if dialogue_index >= len(dialogues):
                        scene = 2

        keys = pygame.key.get_pressed()

        if scene == 2:
            heira.x += 2

            if keys[pygame.K_UP]:
                heira.y -= speed
            if keys[pygame.K_DOWN]:
                heira.y += speed

            if heira.colliderect(algae):
                scene = 3

            if heira.x > algae.x + algae.width and heira.y < algae.y:
                escaped_algae = True

            if escaped_algae and heira.y > algae.y + algae.height:
                scene = 4

            if siren.colliderect(heira):
                scene = 3

            if heira.x > algae.x + algae.width and not escaped_algae:
                scene = 4

        if scene == 0:
            draw_intro()
        elif scene == 1:
            draw_dialogue()
        elif scene == 2:
            draw_game()
        elif scene == 3:
            draw_game_over()
        elif scene == 4:
            draw_victory()

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    asyncio.run(main())
